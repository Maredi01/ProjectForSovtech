package utilities;

public class Constants {
	 public static final String URL = "https://www.sovtech.co.za/contact-us/";
	    public static final String Path_TestData = "C:\\Users\\Patricia Matjipa\\";
	    public static final String File_TestData = "Sovtech.xlsx";
}
